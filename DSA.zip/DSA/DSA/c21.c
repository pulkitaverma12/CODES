#include<stdio.h>
void main()
{
    int i = 5,j = 5;
    if (i==5 && j==5)
    {
        printf("i love you babyyyy so much <3");
    } 
}