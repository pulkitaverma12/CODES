#include<stdio.h>
void main(){
    int n1=9,n2=78;
    if(n1>n2)
{
   printf("%d n1 is greater\n",n1);
}
else
{
   printf("%d n2 is greatest\n",n2);
}
}