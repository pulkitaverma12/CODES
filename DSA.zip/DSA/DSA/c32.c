#include<stdio.h>
#include<string.h>
void main()
{
    char str1[20]="priyal";
    char str2[]="shreyansh";
    strcat(str1,str2);
    printf("%s",str1);
}