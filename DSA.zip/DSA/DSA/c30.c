#include<stdio.h>
#include<string.h>
void main()
{
    char name [50]="Shreyansh";
    strcpy(name," Shreyansh I love you");
    printf("%s\n",name);

}