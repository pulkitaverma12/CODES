#include<stdio.h>
#include <string.h>
void main()
{
   char name[]="Your Name";
   strcpy(name, "I m Idiot");
   printf("%s\n",name);
}