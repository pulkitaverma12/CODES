#include<stdio.h>
void display();   //function prototype(function declaration)
void main()          
{
     display();  //function calling
}
void display()    //calley function
{
    printf("hello!");
}
