#include <iostream>
#include <cmath>
#include <vector>
#include <memory>
using namespace std;
class Shape {
public:
    virtual double Area() const = 0; 
    virtual ~Shape() = default;    
};
class Circle : public Shape {
    int x, y, r; 
public:
    Circle(int x, int y, int r) : x(x), y(y), r(r) {}

    double Area() const override {
        return M_PI * r * r;
    }
};
class Rectangle : public Shape {
    int x1, y1, x2, y2; 
public:
    Rectangle(int x1, int y1, int x2, int y2) : x1(x1), y1(y1), x2(x2), y2(y2) {}

    double Area() const override {
        return abs(x2 - x1) * abs(y1 - y2);
    }
};
class Triangle : public Shape {
    int x1, y1, x2, y2, x3, y3; 
public:
    Triangle(int x1, int y1, int x2, int y2, int x3, int y3)
        : x1(x1), y1(y1), x2(x2), y2(y2), x3(x3), y3(y3) {}

    double Area() const override {
        return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0;
    }
};

int main() {
    int q;
    cout << "Enter the number of queries: ";
    cin >> q;

    vector<unique_ptr<Shape>> shapes;
    for (int i = 0; i < q; ++i) {
        int shapeType;
        cout << "Enter query: ";
        cin >> shapeType;

        if (shapeType == 1) { // Circle
            int x, y, r;
            cin >> x >> y >> r;
            shapes.push_back(make_unique<Circle>(x, y, r));
        } else if (shapeType == 2) { // Rectangle
            int x1, y1, x2, y2;
            cin >> x1 >> y1 >> x2 >> y2;
            shapes.push_back(make_unique<Rectangle>(x1, y1, x2, y2));
        } else if (shapeType == 3) { // Triangle
            int x1, y1, x2, y2, x3, y3;
            cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
            shapes.push_back(make_unique<Triangle>(x1, y1, x2, y2, x3, y3));
        }
    }

    cout << "Areas of the shapes:\n";
    for (const auto& shape : shapes) {
        cout << shape->Area() << endl;
    }

    return 0;
}