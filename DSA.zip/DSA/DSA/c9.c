#include<stdio.h>
int main()
{
char A;
printf("Enter the character: ");
scanf("%c",&A);
printf("ASCII value of %c=%d",A,A);
}