#include<stdio.h>
#include<string.h>
void main()
{
   char name[]="SHREYANSH";
   int length=strlen(name);
   printf("%d\n",length);
   printf("%d\n",name);
   printf("%s\n",name);
}