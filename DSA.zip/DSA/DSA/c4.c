#include<Stdio.h>
int main()
{
    int a=10,b=3;
    //float c= (float)(a/b); ans=3.0
    //float c=a/b;    ans=3.0
    float c=(float)a/b;    //ans=3.333
    printf("%f",c);
   
}